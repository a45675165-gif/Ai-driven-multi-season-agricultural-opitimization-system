import matplotlib.pyplot as plt

# ---------- Style ----------
plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 11,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.titleweight": "bold",
})
BASE = "#9AA5B1"   # baseline (grey)
POST = "#2E9E5B"   # post-implementation (green)
ACC = "#1F6FB2"    # accent (blue)
DPI = 300

# ---------- Data (from project evaluation) ----------
weeks = ["Week 1", "Week 2", "Week 3", "Week 4"]
elec_w = [10.2, 15.4, 19.1, 22.7]
water_w = [12.8, 19.6, 24.3, 29.0]
waste_w = [14.1, 22.0, 28.5, 33.4]

EF = 0.475
elec_base, elec_post = 18420, 14994
saved_kwh = elec_base - elec_post
co2_base = elec_base * EF
co2_post = elec_post * EF
co2_saved = saved_kwh * EF


# ---------- Fig 1: Baseline vs post-implementation ----------
def fig1():
    data = [
        ("Electricity (kWh/month)", 18420, 14994, "18.6%"),
        ("Water (L/month)", 1284000, 983904, "23.4%"),
        ("Solid waste (kg/month)", 1920, 1386.24, "27.8%"),
    ]
    fig, axes = plt.subplots(1, 3, figsize=(11, 4))
    for ax, (title, b, p, red) in zip(axes, data):
        bars = ax.bar(["Baseline", "Post"], [b, p], color=[BASE, POST], width=0.55)
        ax.set_title(title, fontsize=11)
        ax.set_ylim(0, b * 1.22)
        for bar, v in zip(bars, [b, p]):
            ax.text(bar.get_x() + bar.get_width() / 2, v * 1.02, f"{v:,.0f}" if v > 2000 else f"{v:,.2f}".rstrip("0").rstrip("."),
                    ha="center", va="bottom", fontsize=10)
        ax.text(0.5, 0.93, f"-{red}", transform=ax.transAxes, ha="center",
                fontsize=14, fontweight="bold", color=POST)
        ax.ticklabel_format(axis="y", style="plain")
        ax.set_yticks([])
        ax.spines["left"].set_visible(False)
    fig.suptitle("Baseline vs post-implementation consumption", fontweight="bold", fontsize=13)
    fig.tight_layout()
    fig.savefig("fig1_baseline_vs_post.png", dpi=DPI)
    plt.close(fig)


# ---------- Fig 2: Weekly reduction trend ----------
def fig2():
    fig, ax = plt.subplots(figsize=(7, 4.5))
    series = [
        ("Electricity", elec_w, "#E0A100", "o"),
        ("Water", water_w, ACC, "s"),
        ("Solid waste", waste_w, POST, "^"),
    ]
    for name, vals, c, m in series:
        ax.plot(weeks, vals, marker=m, color=c, linewidth=2.5, markersize=8, label=name)
        for x, v in zip(weeks, vals):
            ax.annotate(f"{v}%", (x, v), textcoords="offset points", xytext=(0, 9),
                        ha="center", fontsize=9, color=c)
    ax.set_ylabel("Reduction vs baseline (%)")
    ax.set_ylim(0, 40)
    ax.set_title("Weekly reduction trend")
    ax.grid(axis="y", alpha=0.3)
    ax.legend(frameon=False, loc="upper left")
    fig.tight_layout()
    fig.savefig("fig2_weekly_trend.png", dpi=DPI)
    plt.close(fig)


# ---------- Fig 3: Anomaly-detection funnel ----------
def fig3():
    labels = ["Detected", "Potentially actionable", "Investigated", "Confirmed actionable"]
    vals = [170, 142, 128, 116]
    colors = ["#B8C4D0", "#8FB3D6", "#5A93C4", ACC]
    fig, ax = plt.subplots(figsize=(7, 4))
    y = range(len(vals))
    ax.barh(y, vals, color=colors, height=0.6)
    ax.set_yticks(list(y))
    ax.set_yticklabels(labels)
    ax.invert_yaxis()
    for i, v in enumerate(vals):
        ax.text(v + 2, i, str(v), va="center", fontweight="bold")
    ax.set_xlim(0, 195)
    ax.set_xlabel("Number of abnormal events")
    ax.set_title("Anomaly-detection funnel")
    fig.tight_layout()
    fig.savefig("fig3_anomaly_funnel.png", dpi=DPI)
    plt.close(fig)


# ---------- Fig 4: Student participation ----------
def fig4():
    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    labels = ["Participation\nbaseline", "Participation\npost", "Joined ≥1\nchallenge"]
    vals = [31.8, 53.6, 84.7]
    bars = ax.bar(labels, vals, color=[BASE, POST, ACC], width=0.55)
    for b, v in zip(bars, vals):
        ax.text(b.get_x() + b.get_width() / 2, v + 1.5, f"{v}%", ha="center", fontweight="bold")
    ax.annotate("", xy=(1, 53.6 + 8), xytext=(0, 31.8 + 8),
                arrowprops=dict(arrowstyle="->", color="black"))
    ax.text(0.5, 47, "+68.6% relative\n(+21.8 pp)", ha="center", fontsize=10)
    ax.set_ylim(0, 100)
    ax.set_ylabel("Students (%)")
    ax.set_title("Student participation")
    fig.tight_layout()
    fig.savefig("fig4_participation.png", dpi=DPI)
    plt.close(fig)


# ---------- Fig 5: Estimated avoided emissions ----------
def fig5():
    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    bars = ax.bar(["Baseline", "Post-implementation"], [co2_base, co2_post],
                  color=[BASE, POST], width=0.5)
    for b, v in zip(bars, [co2_base, co2_post]):
        ax.text(b.get_x() + b.get_width() / 2, v + 120, f"{v:,.2f}", ha="center", fontweight="bold")
    ax.annotate("", xy=(1, co2_post), xytext=(1, co2_base),
                arrowprops=dict(arrowstyle="<->", color="black"))
    ax.text(1.28, (co2_base + co2_post) / 2, f"Avoided\n{co2_saved:,.2f} kg\nCO₂e/month",
            va="center", fontsize=10, color=POST, fontweight="bold")
    ax.set_xlim(-0.5, 1.9)
    ax.set_ylim(0, co2_base * 1.15)
    ax.set_ylabel("kg CO₂e / month")
    ax.set_title("Estimated electricity-related emissions")
    ax.text(0.5, -0.16, "Emission factor: 0.475 kg CO₂e/kWh", transform=ax.transAxes,
            ha="center", fontsize=9, color="dimgray")
    fig.tight_layout()
    fig.savefig("fig5_carbon_impact.png", dpi=DPI)
    plt.close(fig)


if __name__ == "__main__":
    for f in (fig1, fig2, fig3, fig4, fig5):
        f()
    print(f"Saved 5 figures. Avoided CO2e = {co2_saved:.2f} kg/month")
